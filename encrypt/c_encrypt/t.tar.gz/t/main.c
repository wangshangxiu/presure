#include "aes.h"
#include <stdio.h>
#include <string.h>
//#include <openssl/evp.h>
 
int main(int arc, char *argv[])
{
  /* Set up the key and iv. Do I need to say to not hard code these in a
   * real application? :-)
   */
 
  /* A 256 bit key */
  unsigned char *key = "12345678901234561234567890123456";
 
  /* A 128 bit IV */
  unsigned char *iv = "1234567890123456";
 
  /* Message to be encrypted */
  unsigned char *plaintext =
    "aes加密数据测试样例1";
 
  /* Buffer for ciphertext. Ensure the buffer is long enough for the
   * ciphertext which may be longer than the plaintext, dependant on the
   * algorithm and mode
   */
  unsigned char ciphertext[1024];
 
  /* Buffer for the decrypted text */
  unsigned char decryptedtext[1024];
 
  int decryptedtext_len, ciphertext_len;
 
  /* Initialise the library */
/*  ERR_load_crypto_strings();
  OpenSSL_add_all_algorithms();
  OPENSSL_config(NULL);*/
 
  printf("Plaintext is:\n%s~\n", plaintext);
 
  /* Encrypt the plaintext */
  ciphertext_len = encrypt(plaintext, strlen(plaintext), key, iv,
    ciphertext);
 
char endatabase64[1024]="";
base64_encode(ciphertext,ciphertext_len,endatabase64);
printf("encode64:%s\n", endatabase64);
  /* Do something useful with the ciphertext here */
  printf("Ciphertext is %d bytes long:\n", ciphertext_len);
  BIO_dump_fp(stdout, ciphertext, ciphertext_len);
 
  /* Decrypt the ciphertext */
  decryptedtext_len = decrypt(ciphertext, ciphertext_len, key, iv,
    decryptedtext);
 
  /* Add a NULL terminator. We are expecting printable text */
  decryptedtext[decryptedtext_len] = '\0';
 
  /* Show the decrypted text */
  printf("Decrypted text is:\n");
  printf("%s~\n", decryptedtext);
 
  /* Clean up */
  EVP_cleanup();
  ERR_free_strings();
 
  return 0;
}
